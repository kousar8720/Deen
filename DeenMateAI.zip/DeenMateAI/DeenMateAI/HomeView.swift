import SwiftUI

struct HomeView: View {
    private let columns = [
        GridItem(.flexible(), spacing: 16),
        GridItem(.flexible(), spacing: 16)
    ]
    
    @State private var showComingSoon = false   // For Quran alert
    
    var body: some View {
        ScrollView {
            VStack(spacing: 32) {
                
                // Top Logo & Title
                VStack(spacing: 16) {
                    Image("AppLogo")
                        .resizable()
                        .renderingMode(.original)
                        .frame(width: 150, height: 150)
                    
                    Text("DeenMate AI")
                        .font(.system(size: 36, weight: .bold))
                        .foregroundColor(.white)
                }
                .padding(.top, 40)
                
                // Grid of Feature Cards
                LazyVGrid(columns: columns, spacing: 16) {
                    
                    // Quran (Coming Soon)
                    HomeCard(systemIcon: "book.closed.fill", title: "Quran")
                        .overlay(
                            Text("COMING SOON")
                                .font(.caption2.bold())
                                .padding(4)
                                .background(Color.red)
                                .foregroundColor(.white)
                                .rotationEffect(.degrees(-20))
                                .offset(x: 20, y: -20),
                            alignment: .topTrailing
                        )
                        .onTapGesture { showComingSoon = true }
                    
                    // Prayer Times (NavigationLink)
                    NavigationLink {
                        PrayerTimesView()   // Destination
                    } label: {
                        HomeCard(systemIcon: "clock", title: "Prayer Times")
                    }
                    .buttonStyle(.plain)   // Removes blue highlight
                    
                    // Tasbih
                    NavigationLink {
                        TasbihView()
                    } label: {
                        HomeCard(systemIcon: "circle.dotted", title: "Tasbih")
                    }
                    .buttonStyle(.plain)
                        // .onTapGesture { /* navigate to TasbihView */ }
                    
                    // Duas
                    // Inside your grid or list of Home cards
                    NavigationLink {
                        DuasView()
                    } label: {
                        HomeCard(systemIcon: "hands.sparkles", title: "Duas")   // Adjust to your own card component
                    }
                        // .onTapGesture { /* navigate to DuasView */ }
                    
                    // Zakat Calculator
                    NavigationLink {
                        ZakatCalculatorView()
                    } label: {
                        HomeCard(systemIcon: "dollarsign.circle", title: "Zakat\nCalculator")
                    }
                        // .onTapGesture { /* navigate to ZakatCalculatorView */ }
                    
                    // Qibla
                    NavigationLink {
                        QiblaView()
                    } label: {
                        HomeCard(systemIcon: "location.north.fill", title: "Qibla")
                    }
                        // .onTapGesture { /* navigate to QiblaView */ }
                }
                .padding(.horizontal, 16)
                
                Spacer(minLength: 32) // breathing room above tab bar
            }
        }
        .background(Color("Surface").ignoresSafeArea())
        .alert("Quran feature coming soon!", isPresented: $showComingSoon) {
            Button("OK", role: .cancel) { }
        }
    }
}
