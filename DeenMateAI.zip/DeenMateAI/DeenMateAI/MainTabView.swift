import SwiftUI

struct MainTabView: View {
    @State private var selected = 0
    
    var body: some View {
        ZStack(alignment: .bottom) {
            TabView(selection: $selected) {
                
                // Home tab wrapped in NavigationStack
                NavigationStack { HomeView() }
                    .tag(0)
                
                DailyVerseView()  .tag(1)
                AskAIView()       .tag(2)
                PremiumView()     .tag(3)
                SettingsView()    .tag(4)
            }
            .onAppear { UITabBar.appearance().isHidden = true }
            
            CustomTabBar(selected: $selected)
        }
    }
}
