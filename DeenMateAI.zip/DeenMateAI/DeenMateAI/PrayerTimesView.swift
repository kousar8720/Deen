import SwiftUI
import CoreLocation

struct PrayerTimesView: View {
    // MARK: - State / ViewModels
    @StateObject private var vm = PrayerTimesViewModel()
    @StateObject private var locManager = LocationManager()
    
    @State private var city: String = "Your City"
    
    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                
                // MARK: Header (Logo, App Name, City, Date)
                headerSection
                
                // MARK: Next Prayer Card
                nextPrayerCard
                
                // MARK: List of Today's Prayer Times
                VStack(spacing: 12) {
                    ForEach(vm.prayerTimes) { prayer in
                        prayerRow(prayer)
                    }
                }
            }
            .padding()
        }
        .background(Color("Surface").ignoresSafeArea())
        .navigationTitle("Prayer Times")                 // System back button appears automatically
        .navigationBarTitleDisplayMode(.inline)
        .onChange(of: locManager.location) { _, newLoc in
            guard let loc = newLoc else { return }
            vm.load(latitude: loc.coordinate.latitude,
                    longitude: loc.coordinate.longitude)
            fetchCity(from: loc)
        }
        .onAppear {
            if let loc = locManager.location {
                vm.load(latitude: loc.coordinate.latitude,
                        longitude: loc.coordinate.longitude)
                fetchCity(from: loc)
            }
        }
    }
}

// MARK: - Subviews
private extension PrayerTimesView {
    
    // Header
    var headerSection: some View {
        VStack(spacing: 4) {
            Image("AppLogo")
                .resizable()
                .renderingMode(.template)
                
                .frame(width: 98, height: 98)
            
            Text("DeenMate AI")
                .font(.title.bold())
                .foregroundColor(.white)
            
            Text(city)
                .font(.subheadline)
                .foregroundColor(Color("Secondary"))
            
            Text(Date(), style: .date)
                .font(.footnote)
                .foregroundColor(Color("Secondary"))
        }
        .padding(.top, 12)
    }
    
    // Next Prayer Banner
    var nextPrayerCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Next Prayer")
                .font(.subheadline.weight(.medium))
                .foregroundColor(Color("Secondary"))
            
            if let next = vm.nextPrayer {
                Text(next.name)
                    .font(.system(size: 48, weight: .bold))
                    .foregroundColor(Color("Primary"))
                
                Text(next.time, style: .time)
                    .font(.title2.monospacedDigit())
                    .foregroundColor(.white)
            } else {
                ProgressView()
                    .progressViewStyle(
                        CircularProgressViewStyle(tint: Color("Primary"))
                    )
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 24)
                .fill(Color("Surface").opacity(0.9))
                .overlay(
                    RoundedRectangle(cornerRadius: 24)
                        .stroke(Color("Primary").opacity(0.4), lineWidth: 1)
                )
        )
    }
    
    // Individual Prayer Row
    func prayerRow(_ prayer: PrayerTime) -> some View {
        HStack(spacing: 16) {
            Image(systemName: iconName(for: prayer.name))
                .font(.system(size: 20))
                .foregroundColor(.white)
                .frame(width: 32, height: 32)
                .background(
                    Circle()
                        .fill(Color("Primary").opacity(0.25))
                )
            
            Text(prayer.name)
                .font(.headline)
                .foregroundColor(.white)
            
            Spacer()
            
            Text(prayer.time, style: .time)
                .font(.headline.monospacedDigit())
                .foregroundColor(.white)
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(Color("Surface").opacity(0.7))
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color("Primary").opacity(0.3), lineWidth: 1)
                )
        )
    }
    
    // Icon mapping
    func iconName(for prayer: String) -> String {
        switch prayer {
        case "Fajr":     return "moon.fill"
        case "Dhuhr":    return "sun.max.fill"
        case "Asr":      return "sun.and.horizon.fill"
        case "Maghrib":  return "moon.stars.fill"
        case "Isha":     return "moon.zzz.fill"
        default:         return "clock"
        }
    }
    
    // Reverse‑geocode city name
    func fetchCity(from location: CLLocation) {
        let geocoder = CLGeocoder()
        geocoder.reverseGeocodeLocation(location) { placemarks, _ in
            if let cityName = placemarks?.first?.locality {
                city = cityName
            }
        }
    }
}

// MARK: - Preview
#Preview {
    NavigationStack {
        PrayerTimesView()
    }
    .preferredColorScheme(.dark)
}
