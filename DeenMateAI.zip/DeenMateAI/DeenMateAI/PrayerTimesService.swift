//
//  PrayerTimesResponse.swift
//  DeenMateAI
//
//  Created by administrator on 28/06/2025.
//


import Foundation

// MARK: - API Response Models
struct PrayerTimesResponse: Decodable {
    let data: [DayData]
    
    struct DayData: Decodable {
        let timings: [String: String]
    }
}

// MARK: - Service
final class PrayerTimesService {
    private let calendar = Calendar.current
    private let session  = URLSession.shared
    
    func fetchPrayerTimes(
        latitude: Double,
        longitude: Double,
        completion: @escaping (Result<[PrayerTime], Error>) -> Void
    ) {
        let today = Date()
        let comps = calendar.dateComponents([.day, .month, .year], from: today)
        guard let day = comps.day,
              let month = comps.month,
              let year = comps.year else {
            completion(.failure(NSError(domain: "DateError", code: -1)))
            return
        }
        
        let urlStr = "https://api.aladhan.com/v1/calendar/\(year)/\(month)?latitude=\(latitude)&longitude=\(longitude)&method=2"
        guard let url = URL(string: urlStr) else {
            completion(.failure(NSError(domain: "URLError", code: -1)))
            return
        }
        
        session.dataTask(with: url) { data, _, error in
            if let error = error { completion(.failure(error)); return }
            guard let data = data else {
                completion(.failure(NSError(domain: "DataError", code: -1)))
                return
            }
            
            do {
                let decoded = try JSONDecoder().decode(PrayerTimesResponse.self, from: data)
                let dayIndex = day - 1
                guard decoded.data.indices.contains(dayIndex) else {
                    completion(.failure(NSError(domain: "IndexError", code: -1)))
                    return
                }
                let timings = decoded.data[dayIndex].timings
                completion(.success(self.parseTimings(timings, today: today)))
            } catch {
                completion(.failure(error))
            }
        }
        .resume()
    }
    
    private func parseTimings(_ dict: [String: String], today: Date) -> [PrayerTime] {
        let names = ["Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"]
        let keys  = ["Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"]
        
        let df = DateFormatter()
        df.dateFormat = "HH:mm"
        df.timeZone   = .current
        
        var result: [PrayerTime] = []
        for (idx, key) in keys.enumerated() {
            guard let raw = dict[key]?.components(separatedBy: " ").first,
                  let timeOnly = df.date(from: raw) else { continue }
            
            let comps = Calendar.current.dateComponents([.year, .month, .day], from: today)
            if let fullDate = Calendar.current.date(bySettingHour: Calendar.current.component(.hour, from: timeOnly),
                                                    minute: Calendar.current.component(.minute, from: timeOnly),
                                                    second: 0,
                                                    of: Calendar.current.date(from: comps)!) {
                result.append(PrayerTime(name: names[idx], time: fullDate))
            }
        }
        return result
    }
}