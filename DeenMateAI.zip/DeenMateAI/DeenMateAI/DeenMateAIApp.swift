import SwiftUI

@main
struct DeenMateAIApp: App {
    @State private var showSplash = true
    
    var body: some Scene {
        WindowGroup {
            if showSplash {
                SplashView()
                    .preferredColorScheme(.dark)
                    .onAppear {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            withAnimation { showSplash = false }
                        }
                    }
            } else {
                MainTabView()
                    .preferredColorScheme(.dark)
            }
        }
    }
}
