import Foundation
import Combine

/// Manages fetching, selecting next prayer, and countdown.
final class PrayerTimesViewModel: ObservableObject {
    @Published var prayerTimes: [PrayerTime] = []
    @Published var nextPrayer: PrayerTime?
    @Published var countdown: String = "--:--:--"
    
    private let service = PrayerTimesService()
    private var timer: AnyCancellable?
    
    func load(latitude: Double, longitude: Double) {
        service.fetchPrayerTimes(latitude: latitude, longitude: longitude) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let times):
                    self?.prayerTimes = times.sorted { $0.time < $1.time }
                    self?.updateNextPrayer()
                    self?.startTimer()
                case .failure(let error):
                    print("PrayerTimesViewModel error:", error.localizedDescription)
                }
            }
        }
    }
    
    // MARK: - Private
    private func startTimer() {
        timer?.cancel()
        timer = Timer.publish(every: 1, on: .main, in: .common)
            .autoconnect()
            .sink { [weak self] _ in self?.tick() }
    }
    
    private func updateNextPrayer() {
        let now = Date()
        if let upcoming = prayerTimes.first(where: { $0.time > now }) {
            nextPrayer = upcoming
        } else {
            nextPrayer = prayerTimes.first // Next day’s Fajr
        }
    }
    
    private func tick() {
        guard let next = nextPrayer else { return }
        let diff = Int(next.time.timeIntervalSinceNow)
        if diff <= 0 {
            updateNextPrayer()
            return
        }
        let h = diff / 3600
        let m = (diff % 3600) / 60
        let s = diff % 60
        countdown = String(format: "%02d:%02d:%02d", h, m, s)
    }
}
