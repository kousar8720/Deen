//
//  QuranAyah.swift
//  DeenMateAI
//
//  Created by administrator on 02/07/2025.
//


import Foundation

/// Flattened ayah model used throughout the app
struct QuranAyah: Identifiable {
    let id: Int          // Global ayah number (1…6236)
    let surah: Int       // Surah number
    let ayah: Int        // Ayah within surah
    let arabic: String   // Arabic text
    let translation: String
}
