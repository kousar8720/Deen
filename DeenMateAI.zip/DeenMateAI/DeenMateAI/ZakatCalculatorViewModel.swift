//
//  ZakatCalculatorViewModel.swift
//  DeenMateAI
//
//  Created by administrator on 30/06/2025.
//


import SwiftUI
import Combine

@MainActor
final class ZakatCalculatorViewModel: ObservableObject {
    
    // MARK: - Published
    @Published var input = ZakatInput() {
        didSet { calculate() }
    }
    @Published var nisabType: Nisab = .gold {
        didSet { calculate() }
    }
    @Published private(set) var zakatDue: Double? = nil
    
    enum Nisab: String, CaseIterable, Identifiable {
        case gold, silver
        var id: String { rawValue }
        
        /// Approx. Nisab values in local currency
        var threshold: Double {
            switch self {
            case .gold:   return 5000   // replace with live rate if desired
            case .silver: return 400
            }
        }
        
        var label: String {
            switch self {
            case .gold:   return "Gold (87.48 g)"
            case .silver: return "Silver (612.36 g)"
            }
        }
    }
    
    // MARK: - Calculation
    private func calculate() {
        let totalAssets = input.cash + input.gold + input.silver + input.savings
        let netAssets   = max(totalAssets - input.liabilities, 0)
        zakatDue = netAssets >= nisabType.threshold ? netAssets * 0.025 : 0
    }
    
    // Reset
    func reset() {
        input = ZakatInput()
        zakatDue = nil
    }
}