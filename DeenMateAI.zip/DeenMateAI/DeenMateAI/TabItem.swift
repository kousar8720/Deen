//
//  TabItem.swift
//  DeenMateAI
//
//  Created by administrator on 29/06/2025.
//


import Foundation

struct TabItem: Identifiable {
    let id = UUID()
    let icon: String     // SF Symbol name or asset name
    let title: String
    let isCenter: Bool
}