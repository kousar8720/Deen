import SwiftUI

extension Color {
    static let primaryMint   = Color("Primary")
    static let secondaryMint = Color("Secondary")
    static let surface       = Color("Surface")
}
