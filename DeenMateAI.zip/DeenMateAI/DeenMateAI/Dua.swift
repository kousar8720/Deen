import Foundation

struct Dua: Identifiable, Decodable, Equatable {
    let id: Int
    let category: String
    let title: String                 // NEW
    let arabic: String
    let transliteration: String
    let translation: String
    let reference: String
    let tags: [String]?               // NEW (optional so old JSON still works)
}
