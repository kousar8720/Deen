//
//  SettingsView.swift
//  DeenMateAI
//
//  Created by administrator on 29/06/2025.
//


import SwiftUI

struct SettingsView: View {
    @AppStorage("dailyVerseNotification") private var notify = false
    
    var body: some View {
        ZStack {
            Color("Surface").ignoresSafeArea()
            
            VStack(spacing: 24) {
                // Title
                Text("Settings")
                    .font(.title)
                    .foregroundColor(.white)
                
                // Daily Verse Notification Toggle
                Toggle("Daily Verse Notification (8 AM)", isOn: $notify)
                    .toggleStyle(SwitchToggleStyle(tint: .primaryMint))
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(12)
                    // iOS 17 two‑parameter onChange
                    .onChange(of: notify) { _, newValue in
                        Task {
                            if newValue {
                                let granted = await NotificationManager.shared.requestPermission()
                                if granted {
                                    NotificationManager.shared.scheduleDailyVerse()
                                } else {
                                    notify = false // user denied permission
                                }
                            } else {
                                NotificationManager.shared.cancelDailyVerse()
                            }
                        }
                    }
            }
            .padding()
        }
    }
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
            .preferredColorScheme(.dark)
    }
}
