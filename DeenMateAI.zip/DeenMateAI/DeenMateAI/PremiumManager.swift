//
//  PremiumManager.swift
//  DeenMateAI
//
//  Created by administrator on 02/07/2025.
//


import Foundation
import Combine

@MainActor
final class PremiumManager: ObservableObject {
    static let shared = PremiumManager()
    @Published private(set) var isPremium: Bool = false
    
    // Replace with real StoreKit2 purchase / restore
    func unlock() { isPremium = true }
}