import SwiftUI

struct DuasView: View {
    @StateObject private var vm = DuasViewModel()
    
    // Include "Bookmarks" as a special chip
    private var categories: [String] {
        var cats = Array(Set(vm.allDuas.map { $0.category })).sorted()
        cats.insert("Bookmarks", at: 0)
        return cats
    }
    
    var body: some View {
        VStack(spacing: 0) {
            header
            categoryScroll
            duaList
        }
        .background(Color("Surface").ignoresSafeArea())
        .navigationTitle("Duas")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Subviews
private extension DuasView {
    
    // Header (logo + search bar)
    var header: some View {
        VStack(spacing: 8) {
            Image("AppLogo")
                .resizable()
                .renderingMode(.template)
                .frame(width: 40, height: 40)
            
            TextField("Search duas…", text: $vm.searchText)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal)
        }
        .padding(.top, 12)
    }
    
    // Horizontal category chips
    var categoryScroll: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 12) {
                ForEach(categories, id: \.self) { cat in
                    categoryChip(cat)
                }
            }
            .padding(.horizontal)
        }
        .padding(.vertical, 8)
    }
    
    // Dua list
    var duaList: some View {
        List {
            ForEach(vm.filtered) { dua in
                duaCard(dua)
                    .listRowSeparator(.hidden)
                    .listRowBackground(Color.clear)
            }
        }
        .listStyle(.plain)
    }
    
    // Category chip
    func categoryChip(_ category: String) -> some View {
        Button {
            withAnimation {
                vm.selectedCategory =
                    vm.selectedCategory == category ? nil : category
            }
        } label: {
            Text(category)
                .font(.subheadline.weight(.medium))
                .foregroundColor(
                    vm.selectedCategory == category ? .black : .white
                )
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(
                    Capsule().fill(
                        vm.selectedCategory == category
                        ? Color("Primary")
                        : Color("Primary").opacity(0.3)
                    )
                )
        }
        .buttonStyle(.plain)
    }
    
    // Dua card (bookmark button restored)
    func duaCard(_ dua: Dua) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            
            // Title
            Text(dua.title)
                .font(.headline.weight(.semibold))
                .foregroundColor(Color("Primary"))
            
            // Arabic
            Text(dua.arabic)
                .font(.title3.weight(.semibold))
                .foregroundColor(.white)
            
            // Transliteration
            Text(dua.transliteration)
                .font(.subheadline)
                .foregroundColor(Color("Secondary"))
            
            // Translation
            Text(dua.translation)
                .font(.body)
                .foregroundColor(.white)
            
            // Reference + bookmark icon
            HStack {
                Text(dua.reference)
                    .font(.caption)
                    .foregroundColor(Color("Secondary"))
                
                Spacer()
                
                Button { vm.toggleFavorite(dua) } label: {
                    Image(systemName: vm.favorites.contains(dua.id)
                          ? "bookmark.fill" : "bookmark")
                        .foregroundColor(Color("Primary"))
                }
            }
            
            // Tag chips (optional)
            if let tags = dua.tags, !tags.isEmpty {
                HStack(spacing: 6) {
                    ForEach(tags, id: \.self) { tag in
                        Text(tag)
                            .font(.caption2)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(
                                Capsule().fill(Color("Primary").opacity(0.2))
                            )
                    }
                }
            }
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(Color("Surface").opacity(0.8))
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color("Primary").opacity(0.3), lineWidth: 1)
                )
        )
        .padding(.vertical, 4)
    }
}
