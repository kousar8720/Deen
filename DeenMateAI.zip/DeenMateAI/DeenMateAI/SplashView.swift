//
//  SplashView.swift
//  DeenMateAI
//
//  Shows logo + Bismillah, then transitions to MainTabView
//

import SwiftUI

struct SplashView: View {
    @State private var isActive = false
    
    var body: some View {
        ZStack {
            // 1. Full‑screen background
            Color("Surface")
                .ignoresSafeArea()
            
            // 2. Conditional content
            if isActive {
                MainTabView()   // ← new root after splash
            } else {
                VStack(spacing: 24) {
                    
                    // App Logo
                    Image("AppLogo")
                        .resizable()
                        .renderingMode(.template)
                        .scaledToFit()
                        .frame(width: 160, height: 160)
                    
                    // Arabic “Bismillah”
                    Text("بِسْمِ ٱللَّٰهِ")
                        .font(.system(size: 36, weight: .bold))
                        .foregroundColor(Color("TextLight"))
                    
                    // English subtitle
                    Text("In the name of Allah, the Most Gracious, the Most Merciful")
                        .font(.subheadline)
                        .multilineTextAlignment(.center)
                        .foregroundColor(Color("TextDimmed"))
                        .padding(.horizontal)
                    
                
                }
            }
        }
        .onAppear {
            // Auto‑transition after 2 seconds
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                withAnimation(.easeOut(duration: 0.5)) {
                    isActive = true
                }
            }
        }
    }
}

// MARK: - Preview
#Preview {
    SplashView()
        .preferredColorScheme(.dark)
}
