//
//  ShareView.swift
//  DeenMateAI
//
//  Created by administrator on 02/07/2025.
//


import SwiftUI

/// UIKit wrapper for UIActivityViewController
struct ShareView: UIViewControllerRepresentable {
    let activityItems: [Any]
    let applicationActivities: [UIActivity]? = nil
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems,
                                 applicationActivities: applicationActivities)
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController,
                                context: Context) { }
}