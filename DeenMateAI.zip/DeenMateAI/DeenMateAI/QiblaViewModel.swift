import SwiftUI
import CoreLocation

final class QiblaViewModel: NSObject, ObservableObject, CLLocationManagerDelegate {
    
    // MARK: - Published
    @Published var heading: Double = 0
    @Published var qiblaBearing: Double = 0
    @Published var authStatus: CLAuthorizationStatus = .notDetermined
    
    // MARK: - Private
    private let kaabaCoord = CLLocation(latitude: 21.4225, longitude: 39.8262)
    private let locationManager = CLLocationManager()
    
    // MARK: - Init
    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.headingFilter = kCLHeadingFilterNone
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingHeading()
        locationManager.startUpdatingLocation()
    }
    
    // MARK: - CLLocationManagerDelegate
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        DispatchQueue.main.async {
            self.authStatus = manager.authorizationStatus
            if self.authStatus == .authorizedWhenInUse || self.authStatus == .authorizedAlways {
                manager.startUpdatingLocation()
                manager.startUpdatingHeading()
            }
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateHeading newHeading: CLHeading) {
        DispatchQueue.main.async {
            self.heading = newHeading.magneticHeading
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let loc = locations.last else { return }
        let bearing = self.bearing(from: loc, to: self.kaabaCoord)
        DispatchQueue.main.async {
            self.qiblaBearing = bearing
        }
    }
    
    // MARK: - Bearing Calculation
    private func bearing(from: CLLocation, to: CLLocation) -> Double {
        let lat1 = from.coordinate.latitude.radians
        let lon1 = from.coordinate.longitude.radians
        let lat2 = to.coordinate.latitude.radians
        let lon2 = to.coordinate.longitude.radians
        let dLon = lon2 - lon1
        
        let y = sin(dLon) * cos(lat2)
        let x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)
        let brng = atan2(y, x).degrees
        return (brng + 360).truncatingRemainder(dividingBy: 360)
    }
}

// MARK: - Helpers
private extension Double {
    var radians: Double { self * .pi / 180 }
    var degrees: Double { self * 180 / .pi }
}
