//
//  PrayerTime.swift
//  DeenMateAI
//
//  Created by administrator on 28/06/2025.
//


import Foundation

struct PrayerTime: Identifiable {
    let id = UUID()
    let name: String
    let time: Date
}