//
//  DuaService.swift
//  DeenMateAI
//
//  Created by administrator on 30/06/2025.
//


import Foundation

final class DuaService {
    static let shared = DuaService()
    private init() {}
    
    /// Loads and decodes `duas.json` from the main bundle.
    func load() -> [Dua] {
        guard
            let url  = Bundle.main.url(forResource: "duas", withExtension: "json"),
            let data = try? Data(contentsOf: url)
        else { return [] }
        
        do {
            return try JSONDecoder().decode([Dua].self, from: data)
        } catch {
            print("Dua decode error:", error.localizedDescription)
            return []
        }
    }
}