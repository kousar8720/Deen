//
//  ZakatCalculatorView.swift
//  DeenMateAI
//
//  Created by administrator on 30/06/2025.
//


import SwiftUI

struct ZakatCalculatorView: View {
    @StateObject private var vm = ZakatCalculatorViewModel()
    @FocusState private var focused: Field?
    @State private var showBreakdown = false
    
    enum Field { case cash, gold, silver, savings, liabilities }
    
    // Currency format (uses device locale)
    private var currencyFormat: FloatingPointFormatStyle<Double>.Currency {
        .currency(code: Locale.current.currency?.identifier ?? "USD")
            .precision(.fractionLength(2))
    }
    
    var body: some View {
        Form {
            // Header
            Section {
                HStack {
                    Image(systemName: "dollarsign.circle")
                        .font(.system(size: 32))
                        .foregroundColor(Color("Primary"))
                    Text("Zakat Calculator")
                        .font(.title3.weight(.semibold))
                }
                .frame(maxWidth: .infinity, alignment: .center)
            }
            
            // Nisab Picker
            Section("Nisab Type") {
                Picker("Nisab", selection: $vm.nisabType) {
                    ForEach(ZakatCalculatorViewModel.Nisab.allCases) { nisab in
                        Text(nisab.label).tag(nisab)
                    }
                }
                .pickerStyle(.segmented)
            }
            
            // Assets
            Section("Assets") {
                currencyField("Cash", value: $vm.input.cash, field: .cash)
                currencyField("Gold", value: $vm.input.gold, field: .gold)
                currencyField("Silver", value: $vm.input.silver, field: .silver)
                currencyField("Savings & Investments", value: $vm.input.savings, field: .savings)
            }
            
            // Liabilities
            Section("Liabilities") {
                currencyField("Debts / Liabilities", value: $vm.input.liabilities, field: .liabilities)
            }
            
            // Result
            if let due = vm.zakatDue {
                Section {
                    HStack {
                        Text("Zakat Due")
                        Spacer()
                        Text(due, format: currencyFormat)
                            .font(.headline)
                            .foregroundColor(Color("Primary"))
                    }
                    .padding(.vertical, 4)
                    
                    Button("View Breakdown") {
                        showBreakdown = true
                    }
                    .foregroundColor(Color("Secondary"))
                }
            }
        }
        .navigationTitle("Zakat")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            // Reset button
            if vm.zakatDue != nil {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Reset") { vm.reset() }
                }
            }
        }
        .sheet(isPresented: $showBreakdown) {
            BreakdownSheet(vm: vm)
        }
    }
    
    // MARK: - Currency Field Helper
    @ViewBuilder
    private func currencyField(_ title: String,
                               value: Binding<Double>,
                               field: Field) -> some View {
        HStack {
            Text(title)
            Spacer()
            TextField("0", value: value, format: currencyFormat)
                .multilineTextAlignment(.trailing)
                .keyboardType(.decimalPad)
                .focused($focused, equals: field)
        }
    }
}

// MARK: - Breakdown Sheet
private struct BreakdownSheet: View {
    @ObservedObject var vm: ZakatCalculatorViewModel
    private var currencyFormat: FloatingPointFormatStyle<Double>.Currency {
        .currency(code: Locale.current.currency?.identifier ?? "USD")
            .precision(.fractionLength(2))
    }
    
    var body: some View {
        NavigationView {
            List {
                Section("Assets") {
                    row("Cash", vm.input.cash)
                    row("Gold", vm.input.gold)
                    row("Silver", vm.input.silver)
                    row("Savings", vm.input.savings)
                    totalRow("Total Assets", vm.input.cash + vm.input.gold + vm.input.silver + vm.input.savings)
                }
                Section("Liabilities") {
                    row("Liabilities", vm.input.liabilities)
                }
                Section("Net Assets") {
                    totalRow("Net Assets", max(vm.input.cash + vm.input.gold + vm.input.silver + vm.input.savings - vm.input.liabilities, 0))
                    row("Nisab Threshold (\(vm.nisabType.label))", vm.nisabType.threshold)
                }
                if let due = vm.zakatDue {
                    Section("Zakat Due (2.5%)") {
                        totalRow("Amount", due)
                    }
                }
            }
            .navigationTitle("Breakdown")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("Done") { dismiss() } } }
        }
    }
    
    @Environment(\.dismiss) private var dismiss
    
    @ViewBuilder
    private func row(_ label: String, _ value: Double) -> some View {
        HStack {
            Text(label)
            Spacer()
            Text(value, format: currencyFormat)
        }
    }
    
    @ViewBuilder
    private func totalRow(_ label: String, _ value: Double) -> some View {
        HStack {
            Text(label)
                .fontWeight(.semibold)
            Spacer()
            Text(value, format: currencyFormat)
                .fontWeight(.semibold)
        }
    }
}