//
//  DailyVerseViewModel.swift
//  DeenMateAI
//
//  Created by administrator on 02/07/2025.
//

import Foundation
import Combine

// MARK: - Keys for streak tracking
enum StreakKeys {
    static let lastDate  = "dailyVerseLastDate"
    static let streak    = "dailyVerseStreak"
}

// MARK: - Daily Verse ViewModel
@MainActor
final class DailyVerseViewModel: ObservableObject {
    // Published properties
    @Published var todayVerse: QuranAyah?
    @Published var isBookmarked: Bool = false
    @Published var streakCount: Int = 0
    
    // Private
    private let verses = QuranData.shared.verses
    private let calendar = Calendar.current
    private let bookmarksKey = "bookmarkedVerses"
    
    // Init
    init() {
        loadToday()
        checkBookmark()
        updateStreak()
    }
    
    // MARK: - Load Today's Verse
    func loadToday() {
        let dayOfYear = calendar.ordinality(of: .day, in: .year, for: Date()) ?? 1
        todayVerse = verses[(dayOfYear - 1) % verses.count]
    }
    
    // MARK: - Random Verse (Premium)
    func randomVerse() -> QuranAyah {
        verses.randomElement()!
    }
    
    // MARK: - Bookmark Logic
    func toggleBookmark() {
        guard let id = todayVerse?.id else { return }
        
        var set = Set(UserDefaults.standard.array(forKey: bookmarksKey) as? [Int] ?? [])
        if set.contains(id) {
            set.remove(id)
            isBookmarked = false
        } else {
            set.insert(id)
            isBookmarked = true
        }
        UserDefaults.standard.set(Array(set), forKey: bookmarksKey)
    }
    
    /// Exposed so the view can refresh bookmark state after loading a random verse
    func checkBookmark() {
        guard let id = todayVerse?.id else { return }
        let set = Set(UserDefaults.standard.array(forKey: bookmarksKey) as? [Int] ?? [])
        isBookmarked = set.contains(id)
    }
    
    // MARK: - Streak Logic
    private func updateStreak() {
        let today = calendar.startOfDay(for: Date())
        let defaults = UserDefaults.standard
        
        let lastDate = defaults.object(forKey: StreakKeys.lastDate) as? Date
        var streak   = defaults.integer(forKey: StreakKeys.streak)
        
        if let last = lastDate {
            let diff = calendar.dateComponents([.day], from: last, to: today).day ?? 0
            switch diff {
            case 0:  break            // same day, no change
            case 1:  streak += 1      // consecutive day
            default: streak = 1       // missed a day, reset
            }
        } else {
            streak = 1                // first launch
        }
        
        defaults.set(today, forKey: StreakKeys.lastDate)
        defaults.set(streak, forKey: StreakKeys.streak)
        streakCount = streak
    }
}
