//
//  HomeCard.swift
//  DeenMateAI
//
//  Created by administrator on 29/06/2025.
//


import SwiftUI

struct HomeCard: View {
    let systemIcon: String
    let title: String
    
    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: systemIcon)
                .font(.system(size: 32, weight: .medium))
                .foregroundStyle(
                    LinearGradient(
                        colors: [Color("Primary"), Color("Secondary")],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
            Text(title)
                .font(.headline)
                .multilineTextAlignment(.center)
                .foregroundColor(.white)
        }
        .frame(maxWidth: .infinity, minHeight: 120)
        .background(Color.clear)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(
                    LinearGradient(
                        colors: [Color("Primary"), Color("Secondary")],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ),
                    lineWidth: 1
                )
        )
    }
}