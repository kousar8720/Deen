//
//  NotificationManager.swift
//  DeenMateAI
//
//  Created by administrator on 02/07/2025.
//


import UserNotifications

// MARK: - Notification Manager
final class NotificationManager {
    static let shared = NotificationManager()
    private init() { }
    
    // MARK: - Permission
    /// Requests notification permission once; returns `true` if granted.
    func requestPermission() async -> Bool {
        let center = UNUserNotificationCenter.current()
        let granted = try? await center.requestAuthorization(options: [.alert, .sound])
        return granted ?? false
    }
    
    // MARK: - Daily Verse (8 AM)
    func scheduleDailyVerse(hour: Int = 8) {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: ["dailyVerse"])
        
        var date = DateComponents()
        date.hour = hour
        date.minute = 0
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: date, repeats: true)
        
        let content  = UNMutableNotificationContent()
        content.title = "Verse of the Day"
        content.body  = "Tap to read today’s verse."
        content.sound = .default
        
        let request = UNNotificationRequest(
            identifier: "dailyVerse",
            content: content,
            trigger: trigger
        )
        center.add(request)
    }
    
    func cancelDailyVerse() {
        UNUserNotificationCenter.current()
            .removePendingNotificationRequests(withIdentifiers: ["dailyVerse"])
    }
    
    // MARK: - Prayer Time Notifications
    /// Schedule repeating notifications for each prayer in `prayers`.
    func schedulePrayerTimes(_ prayers: [PrayerTime]) {
        // Remove any existing prayer alerts
        let ids = prayers.map { $0.name }
        UNUserNotificationCenter.current()
            .removePendingNotificationRequests(withIdentifiers: ids)
        
        for prayer in prayers {
            schedulePrayer(prayer)
        }
    }
    
    /// Helper: schedule a single prayer alert
    private func schedulePrayer(_ prayer: PrayerTime) {
        var comps = Calendar.current.dateComponents([.hour, .minute], from: prayer.time)
        comps.second = 0
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: comps, repeats: true)
        
        let content = UNMutableNotificationContent()
        content.title = "Prayer Time"
        content.body  = "It's time for \(prayer.name)."
        content.sound = .default
        
        let request = UNNotificationRequest(
            identifier: prayer.name, // unique per prayer
            content: content,
            trigger: trigger
        )
        UNUserNotificationCenter.current().add(request)
    }
}
