//
//  ZakatInput.swift
//  DeenMateAI
//
//  Created by administrator on 30/06/2025.
//


import Foundation

struct ZakatInput: Equatable {
    var cash: Double = 0
    var gold: Double = 0
    var silver: Double = 0
    var savings: Double = 0
    var liabilities: Double = 0
}