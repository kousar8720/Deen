//
//  QuranData.swift
//  DeenMateAI
//
//  Created by administrator on 02/07/2025.
//


import Foundation

// Raw JSON structs
private struct RawSurah: Codable {
    let id: Int
    let verses: [RawVerse]
}

private struct RawVerse: Codable {
    let id: Int
    let text: String
    let translation: String
}

/// Loads quran_en.json and flattens to [QuranAyah]
final class QuranData {
    static let shared = QuranData()
    private(set) var verses: [QuranAyah] = []

    private init() { load() }

    // MARK: - Load & Flatten
    private func load() {
        guard let url = Bundle.main.url(forResource: "quran_en", withExtension: "json") else {
            print("⚠️ quran_en.json not found in bundle")
            return
        }
        
        do {
            let data = try Data(contentsOf: url)
            let rawSurahs = try JSONDecoder().decode([RawSurah].self, from: data)
            
            var flat: [QuranAyah] = []
            var globalID = 1
            
            for surah in rawSurahs {
                for verse in surah.verses {
                    flat.append(
                        QuranAyah(
                            id: globalID,
                            surah: surah.id,
                            ayah: verse.id,
                            arabic: verse.text,
                            translation: verse.translation
                        )
                    )
                    globalID += 1
                }
            }
            
            verses = flat
            print("✅ QuranData loaded: verses.count =", verses.count) // should be 6236
        } catch {
            print("❌ Failed to decode quran_en.json:", error)
        }
    }
}
