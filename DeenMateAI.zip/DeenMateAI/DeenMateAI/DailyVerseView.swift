import SwiftUI

struct DailyVerseView: View {
    // ViewModel
    @StateObject private var vm = DailyVerseViewModel()
    @ObservedObject private var premium = PremiumManager.shared
    
    // Sheet controls
    @State private var showShare   = false
    @State private var shareItems: [Any] = []
    @State private var showPaywall = false
    
    var body: some View {
        ScrollView {
            VStack(spacing: 32) {
                
                // MARK: - Header (Logo & Title)
                VStack(spacing: 12) {
                    Image("AppLogo")
                        .resizable()
                        .renderingMode(.template)
                        .frame(width: 160, height: 160)
                        
                    
                    Text("Verse Of The Day")
                        .font(.title.bold())
                        .foregroundColor(.white)
                    
                    // Streak
                    Text("🔥 Streak: \(vm.streakCount)")
                        .font(.caption)
                        .foregroundColor(Color("Secondary"))
                }
                .padding(.top, 24)
                
                // MARK: - Verse Card
                verseCard
                
                // MARK: - Action Buttons
                actionButtons
            }
            .padding()
        }
        .background(Color("Surface").ignoresSafeArea())
        .sheet(isPresented: $showShare) {
            ShareView(activityItems: shareItems)
        }
        .sheet(isPresented: $showPaywall) {
            PremiumView()
        }
    }
}

// MARK: - Subviews
private extension DailyVerseView {
    
    // Verse Card
    var verseCard: some View {
        VStack(spacing: 16) {
            if let verse = vm.todayVerse {
                Text(verse.arabic)
                    .font(.system(size: 30, weight: .semibold))
                    .multilineTextAlignment(.center)
                    .foregroundColor(.white)
                    .padding(.horizontal)
                
                Text(verse.translation)
                    .font(.body)
                    .foregroundColor(Color("Secondary"))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                
                Text("Qur’an \(verse.surah):\(verse.ayah)")
                    .font(.footnote.weight(.medium))
                    .foregroundColor(Color("Primary"))
            } else {
                ProgressView()
                    .progressViewStyle(
                        CircularProgressViewStyle(tint: Color("Primary"))
                    )
                    .padding()
            }
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(
            RoundedRectangle(cornerRadius: 24)
                .fill(Color("Surface").opacity(0.9))
                .overlay(
                    RoundedRectangle(cornerRadius: 24)
                        .stroke(Color("Primary").opacity(0.4), lineWidth: 1)
                )
        )
    }
    
    // Buttons Row
    var actionButtons: some View {
        HStack(spacing: 32) {
            // Bookmark
            Button(action: vm.toggleBookmark) {
                buttonIcon(vm.isBookmarked ? "bookmark.fill" : "bookmark")
            }
            
            // Share
            Button(action: prepareShare) {
                buttonIcon("square.and.arrow.up")
            }
            
            // Random (Premium)
            Button(action: handleRandom) {
                buttonIcon("shuffle")
            }
        }
    }
    
    // Reusable icon style
    func buttonIcon(_ systemName: String) -> some View {
        Image(systemName: systemName)
            .font(.system(size: 20, weight: .medium))
            .foregroundColor(.white)
            .frame(width: 48, height: 48)
            .background(
                Circle()
                    .stroke(Color("Primary"), lineWidth: 2)
            )
    }
}

// MARK: - Helper Actions
private extension DailyVerseView {
    
    func prepareShare() {
        guard let verse = vm.todayVerse else { return }
        shareItems = [
            "\"\(verse.arabic)\" – \(verse.translation)  (\(verse.surah):\(verse.ayah))"
        ]
        showShare = true
    }
    
    func handleRandom() {
        if premium.isPremium {
            vm.todayVerse = vm.randomVerse()
            vm.checkBookmark()
        } else {
            showPaywall = true
        }
    }
}

// MARK: - Preview
#Preview {
    NavigationStack { DailyVerseView() }
        .preferredColorScheme(.dark)
}
