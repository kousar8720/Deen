import SwiftUI

@MainActor
final class DuasViewModel: ObservableObject {
    
    // MARK: - Published
    @Published var allDuas: [Dua] = DuaService.shared.load()
    @Published var searchText: String = ""
    @Published var selectedCategory: String? = nil
    @Published var favorites: Set<Int> = []
    
    // Persist favorites in UserDefaults
    @AppStorage("duaFavs") private var favData: Data = Data()
    
    // MARK: - Init
    init() {
        loadFavorites()
    }
    
    // MARK: - Favorites Persistence
    private func loadFavorites() {
        if let decoded = try? JSONDecoder().decode(Set<Int>.self, from: favData) {
            favorites = decoded
        }
    }
    
    private func saveFavorites() {
        if let data = try? JSONEncoder().encode(favorites) {
            favData = data
        }
    }
    
    // Toggle favorite
    func toggleFavorite(_ dua: Dua) {
        if favorites.contains(dua.id) {
            favorites.remove(dua.id)
        } else {
            favorites.insert(dua.id)
        }
        saveFavorites()
    }
    
    // MARK: - Filtered List
    var filtered: [Dua] {
        // Helper: normalize text
        func normalize(_ text: String) -> String {
            text
                .lowercased()
                .folding(options: .diacriticInsensitive, locale: .current)
                .replacingOccurrences(of: " ",  with: "")
                .replacingOccurrences(of: "-",  with: "")
                .replacingOccurrences(of: "’", with: "")
        }
        
        // Tokenize search query
        let tokens = searchText
            .lowercased()
            .folding(options: .diacriticInsensitive, locale: .current)
            .split(separator: " ")
            .map { String($0) }
        
        // Start with all duas
        var list = allDuas
        
        // Category filter (special case for "Bookmarks")
        if let cat = selectedCategory {
            if cat == "Bookmarks" {
                list = list.filter { favorites.contains($0.id) }
            } else {
                list = list.filter { $0.category == cat }
            }
        }
        
        // Search filter
        if !tokens.isEmpty {
            list = list.filter { dua in
                let normArabic          = normalize(dua.arabic)
                let normTransliteration = normalize(dua.transliteration)
                let normTranslation     = normalize(dua.translation)
                let normTitle           = normalize(dua.title)
                let normTags            = (dua.tags ?? []).map(normalize)
                
                return tokens.allSatisfy { token in
                    normArabic.contains(token) ||
                    normTransliteration.contains(token) ||
                    normTranslation.contains(token) ||
                    normTitle.contains(token) ||
                    normTags.contains(where: { $0.contains(token) })
                }
            }
        }
        
        return list
    }
}
