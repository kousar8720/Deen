import SwiftUI
import CoreHaptics

struct TasbihView: View {
    @Environment(\.dismiss) private var dismiss
    
    // Persist count
    @AppStorage("tasbihCount") private var count: Int = 0
    
    // Haptics
    @State private var engine: CHHapticEngine?
    
    var body: some View {
        ZStack {
            // Background
            Color("Surface")
                .ignoresSafeArea()
                .overlay(
                    RadialGradient(colors: [
                        Color("Surface"),
                        Color("Surface").opacity(0.6)
                    ], center: .center, startRadius: 0, endRadius: 500)
                    .blendMode(.overlay)
                )
            
            VStack(spacing: 40) {
                
                Spacer(minLength: 0)
                
                // Count
                gradientText("\(count)")
                    .font(.system(size: 96, weight: .bold, design: .monospaced))
                
                // Tap Circle
                Button(action: increment) {
                    ZStack {
                        Circle()
                            .stroke(
                                LinearGradient(
                                    colors: [Color("Primary"), Color("Secondary")],
                                    startPoint: .topLeading, endPoint: .bottomTrailing
                                ),
                                lineWidth: 4
                            )
                            .frame(width: 200, height: 200)
                            .background(
                                Circle()
                                    .fill(Color("Surface").opacity(0.6))
                            )
                        
                        Image(systemName: "plus")
                            .font(.system(size: 48, weight: .bold))
                            .foregroundColor(Color("Primary"))
                    }
                }
                .buttonStyle(.plain)
                
                // Reset Button
                Button(action: reset) {
                    Text("Reset")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding(.horizontal, 40)
                        .padding(.vertical, 14)
                        .background(
                            Capsule()
                                .fill(
                                    LinearGradient(
                                        colors: [Color("Primary"), Color("Secondary")],
                                        startPoint: .topLeading, endPoint: .bottomTrailing
                                    )
                                )
                        )
                }
                .padding(.top, 20)
                
                Spacer(minLength: 0)
            }
            .padding(.bottom, 80) // Pushes entire VStack up so Reset is above tab bar
        }
        .navigationTitle("Tasbih")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear(perform: prepareHaptics)
    }
    
    // MARK: - Gradient Text Helper
    private func gradientText(_ text: String) -> some View {
        LinearGradient(
            colors: [Color("Primary"), Color("Secondary")],
            startPoint: .topLeading, endPoint: .bottomTrailing
        )
        .mask(Text(text))
    }
    
    // MARK: - Actions
    private func increment() {
        count += 1
        fireHaptic()
    }
    
    private func reset() {
        count = 0
        fireHaptic()
    }
    
    // MARK: - Haptics
    private func prepareHaptics() {
        guard CHHapticEngine.capabilitiesForHardware().supportsHaptics else { return }
        do {
            engine = try CHHapticEngine()
            try engine?.start()
        } catch {
            print("Haptic engine error:", error.localizedDescription)
        }
    }
    
    private func fireHaptic() {
        guard CHHapticEngine.capabilitiesForHardware().supportsHaptics else { return }
        let intensity = CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.5)
        let sharpness  = CHHapticEventParameter(parameterID: .hapticSharpness,  value: 0.5)
        let event = CHHapticEvent(eventType: .hapticTransient,
                                  parameters: [intensity, sharpness],
                                  relativeTime: 0)
        do {
            let pattern = try CHHapticPattern(events: [event], parameters: [])
            let player  = try engine?.makePlayer(with: pattern)
            try player?.start(atTime: 0)
        } catch {
            print("Haptic error:", error.localizedDescription)
        }
    }
}

// MARK: - Preview
#Preview {
    NavigationStack {
        TasbihView()
    }
    .preferredColorScheme(.dark)
}
