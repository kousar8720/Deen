//
//  PremiumView.swift
//  DeenMateAI
//
//  Created by administrator on 29/06/2025.
//


import SwiftUI

// MARK: - Plan Model
struct PremiumPlan: Identifiable {
    let id: String
    let title: String
    let subtitle: String
    let price: String
    let tint: Color
}

// MARK: - Premium View
struct PremiumView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var premium = PremiumManager.shared
    
    // Plans
    private let plans: [PremiumPlan] = [
        PremiumPlan(id: "deenmate.monthly",
                    title: "Monthly",
                    subtitle: "1 Month access",
                    price: "₹830",
                    tint: Color("Primary")),
        PremiumPlan(id: "deenmate.yearly",
                    title: "Yearly",
                    subtitle: "12 Months access",
                    price: "₹8,300",
                    tint: Color("Secondary")),
        PremiumPlan(id: "deenmate.lifetime",
                    title: "Lifetime",
                    subtitle: "One‑time purchase",
                    price: "₹24,900",
                    tint: .orange)
    ]
    
    var body: some View {
        ZStack {
            Color("Surface").ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: 25) {
                    
                    // Header
                    VStack(spacing: 1) {
                        Image("AppLogo")
                            .resizable()
                            .renderingMode(.template)
                            .frame(width: 110, height: 110)
                            
                        
                        Text("Unlock DeenMate Premium")
                            .font(.title2.bold())
                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)
                    }
                    .padding(.top, 32)
                    
                    // Perks
                    VStack(alignment: .leading, spacing: 10) {
                        Label("Random Verse every time", systemImage: "shuffle")
                        Label("Unlimited Ask AI chat", systemImage: "bubble.left.and.bubble.right")
                        Label("Future premium perks", systemImage: "sparkles")
                    }
                    .font(.body)
                    .foregroundColor(Color("Secondary"))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal)
                    
                    // Plan Cards
                    VStack(spacing: 20) {
                        ForEach(plans) { plan in
                            planCard(plan)
                        }
                    }
                    .padding(.horizontal)
                    
                    // Close
                    Button("Maybe later") {
                        dismiss()
                    }
                    .foregroundColor(.secondary)
                    .padding(.bottom, 40)
                }
            }
        }
    }
    
    // MARK: - Plan Card
    @ViewBuilder
    private func planCard(_ plan: PremiumPlan) -> some View {
        Button {
            purchase(plan: plan)
        } label: {
            VStack(spacing: 6) {
                Text(plan.title)
                    .font(.headline)
                    .foregroundColor(.white)
                Text(plan.subtitle)
                    .font(.caption)
                    .foregroundColor(Color("Secondary"))
                Text(plan.price)
                    .font(.title3.bold())
                    .foregroundColor(plan.tint)
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 24)
                    .fill(Color("Surface").opacity(0.9))
                    .overlay(
                        RoundedRectangle(cornerRadius: 24)
                            .stroke(plan.tint.opacity(0.6), lineWidth: 1)
                    )
            )
        }
    }
    
    // MARK: - Purchase Stub
    private func purchase(plan: PremiumPlan) {
        // TODO: integrate StoreKit2 purchase
        premium.unlock()   // temporary unlock
        dismiss()
    }
}

struct PremiumView_Previews: PreviewProvider {
    static var previews: some View {
        PremiumView()
            .preferredColorScheme(.dark)
    }
}
