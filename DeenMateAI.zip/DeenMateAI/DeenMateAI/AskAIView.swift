//
//  AskAIView.swift
//  DeenMateAI
//
//  Created by administrator on 29/06/2025.
//


import SwiftUI

struct AskAIView: View {
    var body: some View {
        ZStack {
            Color("Surface").ignoresSafeArea()
            Text("Ask AI")
                .font(.title)
                .foregroundColor(.white)
        }
    }
}

struct AskAIView_Previews: PreviewProvider {
    static var previews: some View {
        AskAIView()
            .preferredColorScheme(.dark)
    }
}