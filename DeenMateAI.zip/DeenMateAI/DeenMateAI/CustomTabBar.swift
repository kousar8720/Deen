//
//  CustomTabBar.swift
//  DeenMateAI
//
//  Created by administrator on 29/06/2025.
//


import SwiftUI

struct CustomTabBar: View {
    @Binding var selected: Int
    
    private let items: [TabItem] = [
        .init(icon: "house.fill",      title: "Home",        isCenter: false),
        .init(icon: "circle",          title: "Daily Verse", isCenter: false),
        .init(icon: "AppLogo",         title: "Ask AI",      isCenter: true),  // central asset
        .init(icon: "star.fill",       title: "Premium",     isCenter: false),
        .init(icon: "gearshape.fill",  title: "Settings",    isCenter: false)
    ]
    
    var body: some View {
        HStack {
            ForEach(Array(items.enumerated()), id: \.element.id) { index, item in
                Spacer()
                Button(action: { selected = index }) {
                    if item.isCenter {
                        VStack(spacing: 4) {
                            Image(item.icon)
                                .resizable()
                                .renderingMode(.original)
                                .frame(width: 50, height: 50)
                            Text(item.title)
                                .font(.caption)
                                .foregroundColor(Color("Primary"))
                        }
                        .offset(y: -10) // lift center icon
                    } else {
                        VStack(spacing: 4) {
                            Image(systemName: item.icon)
                                .font(.system(size: 24, weight: .medium))
                            Text(item.title)
                                .font(.caption)
                        }
                        .foregroundColor(selected == index
                                         ? Color("Primary")
                                         : Color("Secondary"))
                    }
                }
                Spacer()
            }
        }
        .padding(.top, 6)
        .padding(.bottom, 12)
        .background(Color("Surface").ignoresSafeArea(edges: .bottom))
    }
}
