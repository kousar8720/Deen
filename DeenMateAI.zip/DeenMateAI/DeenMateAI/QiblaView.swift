import SwiftUI

struct QiblaView: View {
    @StateObject private var vm = QiblaViewModel()
    @State private var alignedGlow = false
    
    // Alignment tolerance (degrees)
    private let tolerance: Double = 5
    
    var body: some View {
        ZStack {
            // Gradient background
            LinearGradient(colors: [Color("Surface"), .black],
                           startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            
            VStack(spacing: 40) {
                
                // Compass
                ZStack {
                    // Compass ring
                    Image("compass_ring")
                        .resizable()
                        .aspectRatio(1, contentMode: .fit)
                        .rotationEffect(.degrees(-vm.heading)) // keep N up
                        .shadow(radius: 4)
                    
                    // Kaaba icon
                    Image("kaaba_icon")
                        .resizable()
                        .frame(width: 38, height: 38)
                        .shadow(radius: 2)
                    
                    // Needle
                    Image(systemName: "arrowtriangle.up.fill")
                        .resizable()
                        .frame(width: 20, height: 120)
                        .foregroundStyle(
                            LinearGradient(colors: [Color("Primary"), Color("Secondary")],
                                           startPoint: .top, endPoint: .bottom)
                        )
                        .offset(y: -60)
                        .rotationEffect(.degrees(vm.qiblaBearing - vm.heading))
                        .shadow(radius: 3)
                        .glow(if: alignedGlow, color: .green, radius: 10)
                }
                .frame(maxWidth: 320)
                .onChange(of: vm.heading) { checkAlignment() }
                .onChange(of: vm.qiblaBearing) { checkAlignment() }
                
                // Degree readout
                VStack(spacing: 6) {
                    Text("Qibla Direction")
                        .font(.headline)
                        .foregroundColor(Color("Secondary"))
                    Text("\(Int(vm.qiblaBearing))°")
                        .font(.largeTitle.bold())
                        .foregroundColor(Color("Primary"))
                }
            }
            .padding(.top, 40)
        }
        .navigationTitle("Qibla")
        .navigationBarTitleDisplayMode(.inline)
    }
    
    // MARK: - Alignment Glow
    private func checkAlignment() {
        let diff = abs(vm.qiblaBearing - vm.heading)
        alignedGlow = diff < tolerance || diff > (360 - tolerance)
    }
}

// MARK: - Glow Modifier
private extension View {
    @ViewBuilder
    func glow(if active: Bool, color: Color, radius: CGFloat) -> some View {
        if active {
            self
                .shadow(color: color.opacity(0.7), radius: radius)
                .animation(.easeInOut(duration: 0.3), value: active)
        } else {
            self
        }
    }
}
